package com.mycompany.proysmartstorage;

import Objetos.Categoria;
import Objetos.Cliente;
import Objetos.Facturacion;
import Objetos.Posicion;
import Objetos.Producto;
import Objetos.Proveedor;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import objetos.Empleado;
import servicios.Servicio;
import servicios.ServicioCategoria;
import servicios.ServicioCliente;
import servicios.ServicioEmpleado;
import servicios.ServicioFacturacion;
import servicios.ServicioPosicion;
import servicios.ServicioProducto;
import servicios.ServicioProveedor;
import javax.swing.JOptionPane;

public class ProySmartStorage {

    public static void main(String[] args) {
        //Variables para definición de fechas
        SimpleDateFormat ff = new SimpleDateFormat("DD/MM/YY");
        java.sql.Date fechaSql;
        Date fecha;
        String fechaNorm;
        String dia;
        String mes;
        String ao;

        //Stringbuffer
        StringBuffer sb = new StringBuffer();

        //Lista de opciones
        List<Integer> opciones = new ArrayList<Integer>(Arrays.asList(0, 1, 2, 3, 4, 5));
        String letras = "abcdefghijklmnpoqrstuvwxyz";
        //Bandera
        boolean bandera = false;

        //Opciones de usuario
        int opcionA;
        int opcionB;
        int opcionC;

        //Servicios para interacción con base de datos
        ServicioEmpleado servicioEmpleado = new ServicioEmpleado();
        ServicioCategoria servicioCategoria = new ServicioCategoria();
        ServicioCliente servicioCliente = new ServicioCliente();
        ServicioFacturacion servicioFacturacion = new ServicioFacturacion();
        ServicioPosicion servicioPosicion = new ServicioPosicion();
        ServicioProducto servicioProducto = new ServicioProducto();
        ServicioProveedor servicioProveedor = new ServicioProveedor();

        //Objetos para operaciones crud
        Categoria categoria = new Categoria();
        List<Categoria> categorias = new ArrayList<>();

        Cliente cliente = new Cliente();
        List<Cliente> clientes = new ArrayList<>();

        Empleado empleado = new Empleado();
        List<Empleado> empleados = new ArrayList<>();

        Facturacion facturacion = new Facturacion();
        List<Facturacion> facturas = new ArrayList<>();

        Posicion posicion = new Posicion();
        List<Posicion> posiciones = new ArrayList<>();

        Producto producto = new Producto();
        List<Producto> productos = new ArrayList<>();

        Proveedor proveedor = new Proveedor();
        List<Proveedor> proveedores = new ArrayList<>();

        //Inicio del programa
        do {
            //Menu principal -> selección de objetos para modificaciones CRUD
            opcionA = Integer.parseInt(JOptionPane.showInputDialog("¡Bienvenido al sistema gestor de datos de Auto Mercado!\n"
                    + "Por favor digite la opción que necesite visualizar\n"
                    + "0. Salir del programa\n"
                    + "1. Visualizar area de empleados\n"
                    + "2. Visualizar area de clientes\n"
                    + "3. Visualizar area de productos\n"
                    + "4. Visualizar area de proveedores\n"
                    + "5. Facturación\n"));

            for (int i : opciones) {
                if (opcionA == i) {
                    bandera = true;
                }
            }
            if (bandera != true) {
                JOptionPane.showMessageDialog(null, "Lo sentimos, esa opción no es correcta. Por favor intentelo de nuevo");
            } else {
                switch (opcionA) {

                    case 1: //Empleados
                        do {
                            //Menu secundario -> selección de opciones de CRUD
                            opcionB = Integer.parseInt(JOptionPane.showInputDialog("Seleccione la opción que le gustaria ejecutar\n"
                                    + "0. Volver\n"
                                    + "1. Mostrar todos los empleados\n"
                                    + "2. Insertar un empleado\n"
                                    + "3. Actualizar un empleado\n"
                                    + "4. Eliminar un empleado\n"));

                            for (int i : opciones) {
                                if (opcionA == i) {
                                    bandera = true;
                                }
                            }
                            if (bandera != true) {
                                JOptionPane.showMessageDialog(null, "Lo sentimos, esa opción no es correcta. Por favor intentelo de nuevo");
                            } else {
                                switch (opcionB) {
                                    case 1://Muestra de todos los empleados
                                        sb.setLength(0);
                                        empleados = servicioEmpleado.conseguirEmpleados();
                                        if (empleados != null) {
                                            for (Empleado emp : empleados) {
                                                posicion = servicioPosicion.conseguirPosicion(emp.getId_posicion());
                                                sb.append(emp.toString() + "");
                                                sb.append("\n");
                                                sb.append("Posición: " + posicion.getPosicion());
                                                sb.append("\n");
                                                sb.append(" ");
                                                sb.append("\n");

                                            }
                                            JOptionPane.showMessageDialog(null, sb);
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun empleado en el sistema");
                                        }
                                        break;

                                    case 2://Creación del empleado
                                        sb.setLength(0);
                                        posiciones = servicioPosicion.conseguirPosiciones();
                                        empleado.setNombre_empleado(JOptionPane.showInputDialog("Digite el nombre del empleado"));
                                        empleado.setPrimer_apellido_empleado(JOptionPane.showInputDialog("Digite el primer apellido del empleado"));
                                        empleado.setSegundo_apellido_empleado(JOptionPane.showInputDialog("Digite el segundo apellido del empleado"));
                                        empleado.setCorreo_empleado(JOptionPane.showInputDialog("Digite el correo del empleado"));
                                        do {
                                            bandera = false;
                                            dia = JOptionPane.showInputDialog("Digite el dia de la contratación");
                                            for (int i = 0; i <= 30; i++) {
                                                if (i == Integer.parseInt(dia)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El dia introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            mes = JOptionPane.showInputDialog("Digite el mes de la contratación");
                                            for (int i = 0; i <= 12; i++) {
                                                if (i == Integer.parseInt(mes)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El mes introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            ao = JOptionPane.showInputDialog("Digite el año de la contratación, ejemplo: 2002");
                                            for (int i = 1995; i <= 2023; i++) {
                                                if (i == Integer.parseInt(ao)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El dia introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);

                                        sb.append("Digite el numero de posición que le gustaria asignarle al empleado \n");
                                        for (Posicion p : posiciones) {
                                            sb.append("Posicion: " + p.getId_posicion() + " Titulo: " + p.getPosicion() + "\n");
                                        }
                                        empleado.setId_posicion(Integer.parseInt(JOptionPane.showInputDialog(null, sb)));

                                        try {
                                            fecha = ff.parse(dia + "/" + mes + "/" + ao);
                                            fechaSql = new java.sql.Date(fecha.getTime());
                                            empleado.setFecha_contratacion(fechaSql);
                                        } catch (ParseException e) {
                                        }

                                        empleado.setId_empleado(servicioEmpleado.buscarUltimoId());
                                        servicioEmpleado.insertarEmpleado(empleado);
                                        JOptionPane.showMessageDialog(null, "¡Inserción realizada con exito!");
                                        break;

                                    case 3://Actualización de empleados
                                        sb.setLength(0);
                                        empleados = servicioEmpleado.conseguirEmpleados();
                                        if (empleados != null) {
                                            sb.append("Digite el id del empleado que desea actualizar\n");
                                            for (Empleado emp : empleados) {
                                                posicion = servicioPosicion.conseguirPosicion(emp.getId_posicion());
                                                sb.append("ID: " + emp.getId_empleado() + " Nombre: "
                                                        + emp.getNombre_empleado() + " "
                                                        + emp.getPrimer_apellido_empleado() + " "
                                                        + emp.getSegundo_apellido_empleado() + "\n");

                                            }
                                            empleado = servicioEmpleado.conseguirEmpleado(Integer.parseInt(JOptionPane.showInputDialog(sb)));
                                            if (empleado.getId_empleado() != 0) {
                                                do {
                                                    opcionC = Integer.parseInt(JOptionPane.showInputDialog("Seleccione el aspecto que le gustaria modificar\n"
                                                            + "0. Volver\n"
                                                            + "1. Nombre\n"
                                                            + "2. Primer apellido\n"
                                                            + "3. Segundo apellido\n"
                                                            + "4. Correo\n"
                                                            + "5. Fecha de contratación\n"
                                                            + "6. Posición del empleado\n"));

                                                    switch (opcionC) {
                                                        case 1:
                                                            empleado.setNombre_empleado(JOptionPane.showInputDialog("Digite el nuevo nombre del empleado"));
                                                            servicioEmpleado.actualizarEmpleado(empleado);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 2:
                                                            empleado.setPrimer_apellido_empleado(JOptionPane.showInputDialog("Digite el primer apellido nuevo del empleado"));
                                                            servicioEmpleado.actualizarEmpleado(empleado);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 3:
                                                            empleado.setSegundo_apellido_empleado(JOptionPane.showInputDialog("Digite el segundo apellido nuevo del empleado"));
                                                            servicioEmpleado.actualizarEmpleado(empleado);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 4:
                                                            empleado.setCorreo_empleado(JOptionPane.showInputDialog("Digite el correo del proyecto del empleado"));
                                                            servicioEmpleado.actualizarEmpleado(empleado);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 5:
                                                            do {
                                                                bandera = false;
                                                                dia = JOptionPane.showInputDialog("Digite el dia de la contratación");
                                                                for (int i = 0; i <= 30; i++) {
                                                                    if (i == Integer.parseInt(dia)) {
                                                                        bandera = true;
                                                                    }
                                                                }
                                                                if (bandera == false) {
                                                                    JOptionPane.showMessageDialog(null, "El dia introducido no es correcto, por favor intentelo otra vez");
                                                                }
                                                            } while (bandera != true);

                                                            do {
                                                                bandera = false;
                                                                mes = JOptionPane.showInputDialog("Digite el mes de la contratación");
                                                                for (int i = 0; i <= 12; i++) {
                                                                    if (i == Integer.parseInt(mes)) {
                                                                        bandera = true;
                                                                    }
                                                                }
                                                                if (bandera == false) {
                                                                    JOptionPane.showMessageDialog(null, "El mes introducido no es correcto, por favor intentelo otra vez");
                                                                }
                                                            } while (bandera != true);

                                                            do {
                                                                bandera = false;
                                                                ao = JOptionPane.showInputDialog("Digite el año de la contratación, ejemplo: 2002");
                                                                for (int i = 1995; i <= 2023; i++) {
                                                                    if (i == Integer.parseInt(ao)) {
                                                                        bandera = true;
                                                                    }
                                                                }
                                                                if (bandera == false) {
                                                                    JOptionPane.showMessageDialog(null, "El dia introducido no es correcto, por favor intentelo otra vez");
                                                                }
                                                            } while (bandera != true);

                                                            fechaNorm = dia + "/" + mes + "/" + ao;
                                                            try {
                                                                fecha = ff.parse(fechaNorm);
                                                                fechaSql = new java.sql.Date(fecha.getTime());
                                                                empleado.setFecha_contratacion(fechaSql);
                                                                servicioEmpleado.actualizarEmpleado(empleado);
                                                            } catch (ParseException e) {
                                                            }
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 6:
                                                            sb.setLength(0);
                                                            posiciones = servicioPosicion.conseguirPosiciones();
                                                            sb.append("Digite el numero de posición que le gustaria asignarle al empleado \n");
                                                            for (Posicion p : posiciones) {
                                                                sb.append("Posicion: " + p.getId_posicion() + " Titulo: " + p.getPosicion() + "\n");
                                                            }
                                                            empleado.setId_posicion(Integer.parseInt(JOptionPane.showInputDialog(null, sb)));
                                                            servicioEmpleado.actualizarEmpleado(empleado);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                    }
                                                } while (opcionC != 0);
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el empleado digitado no existe");
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun empleado en el sistema");
                                        }
                                        break;

                                    case 4://Eliminación de empleados
                                        sb.setLength(0);
                                        empleados = servicioEmpleado.conseguirEmpleados();
                                        if (empleados != null) {
                                            sb.append("Digite el id del empleado que desea eliminar\n");
                                            for (Empleado emp : empleados) {
                                                posicion = servicioPosicion.conseguirPosicion(emp.getId_posicion());
                                                sb.append("ID: " + emp.getId_empleado() + " Nombre: "
                                                        + emp.getNombre_empleado() + " "
                                                        + emp.getPrimer_apellido_empleado() + " "
                                                        + emp.getSegundo_apellido_empleado() + "\n");

                                            }
                                            empleado = servicioEmpleado.conseguirEmpleado(Integer.parseInt(JOptionPane.showInputDialog(sb)));
                                            if (empleado.getId_empleado() != 0) {
                                                servicioEmpleado.eliminarEmpleado(empleado.getId_empleado());
                                                JOptionPane.showMessageDialog(null, "¡Eliminación realizada con exito!");
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el empleado digitado no esta en el sistema");
                                            }

                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun empleado en el sistema");
                                        }
                                        break;

                                }
                            }
                        } while (opcionB != 0);
                        break;

                    case 2:  //Clientes 
                        do {
                            //Menu secundario -> selección de opciones de CRUD
                            opcionB = Integer.parseInt(JOptionPane.showInputDialog("Seleccione la opción que le gustaria ejecutar\n"
                                    + "0. Volver\n"
                                    + "1. Mostrar todos los clientes\n"
                                    + "2. Insertar un nuevo cliente\n"
                                    + "3. Actualizar un cliente\n"
                                    + "4. Eliminar un cliente\n"));

                            for (int i : opciones) {
                                if (opcionA == i) {
                                    bandera = true;
                                }
                            }
                            if (bandera != true) {
                                JOptionPane.showMessageDialog(null, "Lo sentimos, esa opción no es correcta. Por favor intentelo de nuevo");
                            } else {
                                switch (opcionB) {
                                    case 1://Muestra de todos los clientes
                                        sb.setLength(0);
                                        clientes = servicioCliente.conseguirClientes();
                                        if (clientes != null) {
                                            for (Cliente cli : clientes) {
                                                sb.append(cli.toString() + "");
                                                sb.append("\n");
                                            }
                                            JOptionPane.showMessageDialog(null, sb);
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun empleado en el sistema");
                                        }
                                        break;

                                    case 2://Creación del cliente
                                        sb.setLength(0);
                                        cliente.setNombre_cliente(JOptionPane.showInputDialog("Digite el nombre del cliente"));
                                        cliente.setPrimer_apellido_cliente(JOptionPane.showInputDialog("Digite el primer apellido del cliente"));
                                        cliente.setSegundo_apellido_cliente(JOptionPane.showInputDialog("Digite el segundo apellido del cliente"));
                                        cliente.setCorreo_cliente(JOptionPane.showInputDialog("Digite el correo del cliente"));

                                        do {
                                            bandera = false;
                                            cliente.setTelefono_cliente(JOptionPane.showInputDialog("Digite el telefono del cliente"));
                                            if (cliente.getTelefono_cliente().length() == 8) {
                                                bandera = true;
                                            }

                                            for (int ia = 0; ia < letras.length(); ia++) {
                                                for (int ib = 0; ib < cliente.getTelefono_cliente().length(); ib++) {
                                                    if (cliente.getTelefono_cliente().charAt(ib) == letras.charAt(ia)) {
                                                        bandera = false;
                                                    }
                                                }
                                            }

                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el telefono introducido no es valido");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            cliente.setCedula_cliente(JOptionPane.showInputDialog("Digite la cedula del cliente"));
                                            if (cliente.getCedula_cliente().length() == 9) {
                                                bandera = true;
                                            }

                                            for (int ia = 0; ia < letras.length(); ia++) {
                                                for (int ib = 0; ib < cliente.getCedula_cliente().length(); ib++) {
                                                    if (cliente.getCedula_cliente().charAt(ib) == letras.charAt(ia)) {
                                                        bandera = false;
                                                    }
                                                }
                                            }

                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, la cedula introducida no es valida");
                                            }
                                        } while (bandera != true);

                                        servicioCliente.insertarCliente(cliente);
                                        JOptionPane.showMessageDialog(null, "¡Inserción realizada con exito!");
                                        break;

                                    case 3://Actualización de clientes
                                        sb.setLength(0);
                                        clientes = servicioCliente.conseguirClientes();
                                        if (clientes != null) {
                                            sb.append("Digite la cedula del cliente que desea actualizar\n");
                                            for (Cliente cli : clientes) {
                                                sb.append(cli.toString() + "");
                                                sb.append("\n");
                                            }
                                            cliente = servicioCliente.conseguirCliente(JOptionPane.showInputDialog(sb));
                                            if (cliente.getCedula_cliente() != null) {
                                                do {
                                                    opcionC = Integer.parseInt(JOptionPane.showInputDialog("Seleccione el aspecto que le gustaria modificar\n"
                                                            + "0. Volver\n"
                                                            + "1. Nombre\n"
                                                            + "2. Primer apellido\n"
                                                            + "3. Segundo apellido\n"
                                                            + "4. Correo\n"
                                                            + "5. Telefono\n"));

                                                    switch (opcionC) {
                                                        case 1:
                                                            cliente.setNombre_cliente(JOptionPane.showInputDialog("Digite el nuevo nombre del cliente"));
                                                            servicioCliente.actualizarCliente(cliente);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 2:
                                                            cliente.setPrimer_apellido_cliente(JOptionPane.showInputDialog("Digite el primer apellido nuevo del cliente"));
                                                            servicioCliente.actualizarCliente(cliente);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 3:
                                                            cliente.setSegundo_apellido_cliente(JOptionPane.showInputDialog("Digite el segundo apellido nuevo del cliente"));
                                                            servicioCliente.actualizarCliente(cliente);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 4:
                                                            cliente.setCorreo_cliente(JOptionPane.showInputDialog("Digite el nuevo correo del cliente"));
                                                            servicioCliente.actualizarCliente(cliente);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 5:
                                                            do {
                                                                bandera = false;
                                                                cliente.setTelefono_cliente(JOptionPane.showInputDialog("Digite el telefono del cliente"));
                                                                if (cliente.getTelefono_cliente().length() == 8) {
                                                                    bandera = true;
                                                                }

                                                                for (int ia = 0; ia < letras.length(); ia++) {
                                                                    for (int ib = 0; ib < cliente.getTelefono_cliente().length(); ib++) {
                                                                        if (cliente.getTelefono_cliente().charAt(ib) == letras.charAt(ia)) {
                                                                            bandera = false;
                                                                        }
                                                                    }
                                                                }

                                                                if (bandera == false) {
                                                                    JOptionPane.showMessageDialog(null, "Lo sentimos, el telefono introducido no es valido");
                                                                }
                                                            } while (bandera != true);
                                                            servicioCliente.actualizarCliente(cliente);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                    }
                                                } while (opcionC != 0);
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el empleado digitado no existe");
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun empleado en el sistema");
                                        }
                                        break;

                                    case 4://Eliminación de clientes
                                        sb.setLength(0);
                                        clientes = servicioCliente.conseguirClientes();
                                        if (clientes != null) {
                                            sb.append("Digite la cedula del cliente que desea eliminar\n");
                                            for (Cliente cli : clientes) {
                                                sb.append("Cedula: " + cli.getCedula_cliente() + " Nombre: "
                                                        + cli.getNombre_cliente() + " "
                                                        + cli.getPrimer_apellido_cliente() + " "
                                                        + cli.getSegundo_apellido_cliente() + "\n");

                                            }
                                            cliente = servicioCliente.conseguirCliente(JOptionPane.showInputDialog(sb));
                                            if (cliente.getCedula_cliente() != null) {
                                                servicioFacturacion.eliminarFacturaCliente(cliente.getCedula_cliente());
                                                servicioCliente.eliminarCliente(cliente.getCedula_cliente());
                                                JOptionPane.showMessageDialog(null, "¡Eliminación realizada con exito!");
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el cliente digitado no esta en el sistema");
                                            }

                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun cliente en el sistema");
                                        }
                                        break;

                                }
                            }
                        } while (opcionB != 0);
                        break;

                    case 3:  //Productos 
                        do {
                            //Menu secundario -> selección de opciones de CRUD
                            opcionB = Integer.parseInt(JOptionPane.showInputDialog("Seleccione la opción que le gustaria ejecutar\n"
                                    + "0. Volver\n"
                                    + "1. Mostrar todos los productos\n"
                                    + "2. Insertar un nuevo producto\n"
                                    + "3. Actualizar un producto\n"
                                    + "4. Eliminar un producto\n"));

                            for (int i : opciones) {
                                if (opcionA == i) {
                                    bandera = true;
                                }
                            }
                            if (bandera != true) {
                                JOptionPane.showMessageDialog(null, "Lo sentimos, esa opción no es correcta. Por favor intentelo de nuevo");
                            } else {
                                switch (opcionB) {
                                    case 1://Muestra de todos los productos
                                        sb.setLength(0);
                                        productos = servicioProducto.conseguirProductos();
                                        if (productos != null) {
                                            for (Producto pro : productos) {
                                                sb.append(pro.toString() + "");
                                                sb.append("\n");
                                            }
                                            JOptionPane.showMessageDialog(null, sb);
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun producto en el sistema");
                                        }
                                        break;

                                    case 2://Creación del producto
                                        sb.setLength(0);
                                        proveedores = servicioProveedor.conseguirProveedores();
                                        categorias = servicioCategoria.conseguirCategorias();
                                        producto.setNombre_producto(JOptionPane.showInputDialog("Digite la descripción del producto"));

                                        do {
                                            bandera = true;
                                            producto.setPrecio(Integer.parseInt(JOptionPane.showInputDialog("Digite el precio del producto")));

                                            for (int ia = 0; ia < letras.length(); ia++) {
                                                for (int ib = 0; ib < Float.toString(producto.getPrecio()).length(); ib++) {
                                                    if (Float.toString(producto.getPrecio()).charAt(ib) == letras.charAt(ia)) {
                                                        bandera = false;
                                                    }
                                                }
                                            }

                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, la cantidad del producto la introducida no es valida");
                                            }

                                        } while (bandera != true);

                                        do {
                                            bandera = true;
                                            producto.setCantidad(Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad del producto")));

                                            for (int ia = 0; ia < letras.length(); ia++) {
                                                for (int ib = 0; ib < Float.toString(producto.getPrecio()).length(); ib++) {
                                                    if (Float.toString(producto.getPrecio()).charAt(ib) == letras.charAt(ia)) {
                                                        bandera = false;
                                                    }
                                                }
                                            }

                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, la cantidad del producto la introducida no es valida");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            sb.append("Digite el id del proveedor que le gustaria asignarle al empleado \n");
                                            for (Proveedor p : proveedores) {
                                                sb.append("ID: " + p.getId_proveedor() + " Nombre: " + p.getNombre_proveedor() + "\n");
                                            }

                                            producto.setId_proveedor(Integer.parseInt(JOptionPane.showInputDialog(null, sb)));

                                            for (Proveedor p : proveedores) {
                                                if (producto.getId_proveedor() == p.getId_proveedor()) {
                                                    bandera = true;
                                                }

                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el proveedor introducido no es valido");
                                            }
                                        } while (bandera != true);

                                        do {
                                            sb.setLength(0);
                                            bandera = false;
                                            sb.append("Digite el id de la categoria que le gustaria asignarle al producto \n");
                                            for (Categoria c : categorias) {
                                                sb.append("ID: " + c.getId_categoria() + " Categoria: " + c.getCategoria() + "\n");
                                            }

                                            producto.setId_categoria(Integer.parseInt(JOptionPane.showInputDialog(null, sb)));

                                            for (Categoria c : categorias) {
                                                if (producto.getId_categoria() == c.getId_categoria()) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, la categoria introducida no es valida");
                                            }
                                        } while (bandera != true);
                                        producto.setId_producto(servicioProducto.buscarUltimoId());
                                        servicioProducto.insertarProducto(producto);
                                        JOptionPane.showMessageDialog(null, "¡Inserción realizada con exito!");
                                        break;

                                    case 3: //Actualización de productos
                                        sb.setLength(0);
                                        productos = servicioProducto.conseguirProductos();
                                        if (productos != null) {
                                            sb.append("Digite el id del producto que desea actualizar\n");
                                            for (Producto pro : productos) {
                                                sb.append(pro.toString() + "");
                                                sb.append("\n");
                                            }
                                            producto = servicioProducto.conseguirProducto(Integer.parseInt(JOptionPane.showInputDialog(sb)));
                                            if (producto.getId_producto() != 0) {
                                                do {
                                                    opcionC = Integer.parseInt(JOptionPane.showInputDialog("Seleccione el aspecto que le gustaria modificar\n"
                                                            + "0. Volver\n"
                                                            + "1. Nombre\n"
                                                            + "2. Precio\n"
                                                            + "3. Cantidad disponible\n"
                                                            + "4. Categoria\n"));

                                                    switch (opcionC) {
                                                        case 1:
                                                            producto.setNombre_producto(JOptionPane.showInputDialog("Digite el nuevo nombre del producto"));
                                                            servicioProducto.actualizarProducto(producto);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 2:
                                                            do {
                                                                bandera = true;
                                                                producto.setPrecio(Integer.parseInt(JOptionPane.showInputDialog("Digite el precio del producto")));

                                                                for (int ia = 0; ia < letras.length(); ia++) {
                                                                    for (int ib = 0; ib < Float.toString(producto.getPrecio()).length(); ib++) {
                                                                        if (Float.toString(producto.getPrecio()).charAt(ib) == letras.charAt(ia)) {
                                                                            bandera = false;
                                                                        }
                                                                    }
                                                                }

                                                                if (bandera == false) {
                                                                    JOptionPane.showMessageDialog(null, "Lo sentimos, la cantidad del producto la introducida no es valida");
                                                                }

                                                            } while (bandera != true);
                                                            servicioProducto.actualizarProducto(producto);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 3:
                                                            do {
                                                                bandera = true;
                                                                producto.setCantidad(Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad del producto")));

                                                                for (int ia = 0; ia < letras.length(); ia++) {
                                                                    for (int ib = 0; ib < Float.toString(producto.getPrecio()).length(); ib++) {
                                                                        if (Float.toString(producto.getPrecio()).charAt(ib) == letras.charAt(ia)) {
                                                                            bandera = false;
                                                                        }
                                                                    }
                                                                }

                                                                if (bandera == false) {
                                                                    JOptionPane.showMessageDialog(null, "Lo sentimos, la cantidad del producto la introducida no es valida");
                                                                }
                                                            } while (bandera != true);
                                                            servicioProducto.actualizarProducto(producto);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 4:
                                                            categorias = servicioCategoria.conseguirCategorias();
                                                            do {
                                                                sb.setLength(0);
                                                                bandera = false;
                                                                sb.append("Digite el id de la categoria que le gustaria asignarle al producto \n");
                                                                for (Categoria c : categorias) {
                                                                    sb.append("ID: " + c.getId_categoria() + " Categoria: " + c.getCategoria() + "\n");
                                                                }

                                                                producto.setId_categoria(Integer.parseInt(JOptionPane.showInputDialog(null, sb)));

                                                                for (Categoria c : categorias) {
                                                                    if (producto.getId_categoria() == c.getId_categoria()) {
                                                                        bandera = true;
                                                                    }
                                                                }
                                                                if (bandera == false) {
                                                                    JOptionPane.showMessageDialog(null, "Lo sentimos, la categoria introducida no es valida");
                                                                }
                                                            } while (bandera != true);
                                                            servicioProducto.actualizarProducto(producto);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                    }
                                                } while (opcionC != 0);
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el producto digitado no existe");
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun producto en el sistema");
                                        }
                                        break;

                                    case 4://Eliminación de productos
                                        sb.setLength(0);
                                        productos = servicioProducto.conseguirProductos();
                                        if (productos != null) {
                                            sb.append("Digite el id del producto que desea eliminar\n");
                                            for (Producto pro : productos) {
                                                sb.append("ID: " + pro.getId_producto() + " Nombre: " + pro.getNombre_producto() + "\n");

                                            }
                                            producto = servicioProducto.conseguirProducto(Integer.parseInt(JOptionPane.showInputDialog(sb)));
                                            if (producto.getId_producto() != 0) {
                                                servicioFacturacion.eliminarFacturaProducto(producto.getId_producto());
                                                servicioProducto.eliminarProducto(producto.getId_producto());
                                                JOptionPane.showMessageDialog(null, "¡Eliminación realizada con exito!");
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el producto digitado no esta en el sistema");
                                            }

                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun producto en el sistema");
                                        }
                                        break;
                                }

                            }
                        } while (opcionB != 0);
                        break;

                    case 4: //Proveedores
                        do {
                            //Menu secundario -> selección de opciones de CRUD
                            opcionB = Integer.parseInt(JOptionPane.showInputDialog("Seleccione la opción que le gustaria ejecutar\n"
                                    + "0. Volver\n"
                                    + "1. Mostrar todos los proveedores\n"
                                    + "2. Insertar un proveedor\n"
                                    + "3. Actualizar un proveedor\n"
                                    + "4. Eliminar un proveedor\n"));

                            for (int i : opciones) {
                                if (opcionA == i) {
                                    bandera = true;
                                }
                            }
                            if (bandera != true) {
                                JOptionPane.showMessageDialog(null, "Lo sentimos, esa opción no es correcta. Por favor intentelo de nuevo");
                            } else {
                                switch (opcionB) {
                                    case 1://Muestra de todos los empleados
                                        sb.setLength(0);
                                        proveedores = servicioProveedor.conseguirProveedores();
                                        if (proveedores != null) {
                                            for (Proveedor pro : proveedores) {
                                                sb.append(pro.toString() + "");
                                                sb.append("\n");
                                            }
                                            JOptionPane.showMessageDialog(null, sb);
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun proveedor en el sistema");
                                        }
                                        break;

                                    case 2://Creación del proveedor
                                        sb.setLength(0);
                                        proveedor.setNombre_proveedor(JOptionPane.showInputDialog("Digite el nombre del proveedor"));
                                        proveedor.setCorreo_proveedor(JOptionPane.showInputDialog("Digite el correo del proveedor"));
                                        do {
                                            bandera = false;
                                            proveedor.setTelefono_proveedor(JOptionPane.showInputDialog("Digite el telefono del proveedor"));
                                            if (proveedor.getTelefono_proveedor().length() == 8) {
                                                bandera = true;
                                            }

                                            for (int ia = 0; ia < letras.length(); ia++) {
                                                for (int ib = 0; ib < proveedor.getTelefono_proveedor().length(); ib++) {
                                                    if (proveedor.getTelefono_proveedor().charAt(ib) == letras.charAt(ia)) {
                                                        bandera = false;
                                                    }
                                                }
                                            }

                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el telefono introducido no es valido");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            dia = JOptionPane.showInputDialog("Digite el dia de la contratación");
                                            for (int i = 0; i <= 30; i++) {
                                                if (i == Integer.parseInt(dia)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El dia introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            mes = JOptionPane.showInputDialog("Digite el mes de la contratación");
                                            for (int i = 0; i <= 12; i++) {
                                                if (i == Integer.parseInt(mes)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El mes introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            ao = JOptionPane.showInputDialog("Digite el año de la contratación, ejemplo: 2002");
                                            for (int i = 1995; i <= 2023; i++) {
                                                if (i == Integer.parseInt(ao)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El dia introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);

                                        try {
                                            fecha = ff.parse(dia + "/" + mes + "/" + ao);
                                            fechaSql = new java.sql.Date(fecha.getTime());
                                            proveedor.setFecha_contrato(fechaSql);
                                        } catch (ParseException e) {
                                        }

                                        proveedor.setId_proveedor(servicioProveedor.buscarUltimoId());
                                        servicioProveedor.insertarProveedor(proveedor);
                                        JOptionPane.showMessageDialog(null, "¡Inserción realizada con exito!");
                                        break;

                                    case 3://Actualización de proveedores
                                        sb.setLength(0);
                                        proveedores = servicioProveedor.conseguirProveedores();
                                        if (proveedores != null) {
                                            sb.append("Digite el id del proveedor que desea actualizar\n");
                                            for (Proveedor pro : proveedores) {
                                                sb.append("ID: " + pro.getId_proveedor() + " Nombre:" + pro.getNombre_proveedor() + "\n");
                                            }
                                            proveedor = servicioProveedor.conseguirProveedor(Integer.parseInt(JOptionPane.showInputDialog(sb)));
                                            if (proveedor.getId_proveedor() != 0) {
                                                do {
                                                    opcionC = Integer.parseInt(JOptionPane.showInputDialog("Seleccione el aspecto que le gustaria modificar\n"
                                                            + "0. Volver\n"
                                                            + "1. Nombre\n"
                                                            + "2. Correo\n"
                                                            + "3. Telefono\n"));

                                                    switch (opcionC) {
                                                        case 1:
                                                            proveedor.setNombre_proveedor(JOptionPane.showInputDialog("Digite el nuevo nombre del proveedor"));
                                                            servicioProveedor.actualizarProveedor(proveedor);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 2:
                                                            proveedor.setCorreo_proveedor(JOptionPane.showInputDialog("Digite el nuevo correo del proveedor"));
                                                            servicioProveedor.actualizarProveedor(proveedor);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                        case 3:
                                                            do {
                                                                bandera = false;
                                                                proveedor.setTelefono_proveedor(JOptionPane.showInputDialog("Digite el nuevo telefono del proveedor"));
                                                                if (proveedor.getTelefono_proveedor().length() == 8) {
                                                                    bandera = true;
                                                                }

                                                                for (int ia = 0; ia < letras.length(); ia++) {
                                                                    for (int ib = 0; ib < proveedor.getTelefono_proveedor().length(); ib++) {
                                                                        if (proveedor.getTelefono_proveedor().charAt(ib) == letras.charAt(ia)) {
                                                                            bandera = false;
                                                                        }
                                                                    }
                                                                }

                                                                if (bandera == false) {
                                                                    JOptionPane.showMessageDialog(null, "Lo sentimos, el telefono introducido no es valido");
                                                                }
                                                            } while (bandera != true);
                                                            servicioProveedor.actualizarProveedor(proveedor);
                                                            JOptionPane.showMessageDialog(null, "¡Actualización exitosa!");
                                                            break;

                                                    }
                                                } while (opcionC != 0);
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el proveedor digitado no existe");
                                            }
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun proveedor en el sistema");
                                        }
                                        break;

                                    case 4://Eliminación de proveedores
                                        sb.setLength(0);
                                        productos = servicioProducto.conseguirProductos();
                                        proveedores = servicioProveedor.conseguirProveedores();
                                        if (proveedores != null) {
                                            sb.append("Digite el id del proveedor que desea actualizar\n");
                                            for (Proveedor pro : proveedores) {
                                                sb.append("ID: " + pro.getId_proveedor() + " Nombre:" + pro.getNombre_proveedor() + "\n");
                                            }
                                            proveedor = servicioProveedor.conseguirProveedor(Integer.parseInt(JOptionPane.showInputDialog(sb)));
                                            if (proveedor.getId_proveedor()!= 0) {
                                                for(Producto pro : productos)
                                                {
                                                    if(pro.getId_proveedor() == proveedor.getId_proveedor()){
                                                        servicioFacturacion.eliminarFacturaProducto(pro.getId_producto());
                                                        servicioProducto.eliminarProducto(pro.getId_producto());
                                                    }
                                                }
                                                servicioProveedor.eliminarProveedor(proveedor.getId_proveedor());
                                                JOptionPane.showMessageDialog(null, "¡Eliminación realizada con exito!");
                                            } else {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el proveedor digitado no esta en el sistema");
                                            }

                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ningun proveedor en el sistema");
                                        }
                                        break;
                                }
                            }
                        } while (opcionB != 0);
                        break;
                        
                        case 5: //Facturación
                        do {
                            //Menu secundario -> selección de opciones de CRUD
                            opcionB = Integer.parseInt(JOptionPane.showInputDialog("Seleccione la opción que le gustaria ejecutar\n"
                                    + "0. Volver\n"
                                    + "1. Mostrar todas las facturas\n"
                                    + "2. Realizar una transacción\n"));
                            for (int i : opciones) {
                                if (opcionA == i) {
                                    bandera = true;
                                }
                            }
                            if (bandera != true) {
                                JOptionPane.showMessageDialog(null, "Lo sentimos, esa opción no es correcta. Por favor intentelo de nuevo");
                            } else {
                                switch (opcionB) {
                                    case 1://Mostrar todas las transacciones
                                        sb.setLength(0);
                                        facturas = servicioFacturacion.conseguirFacturas();
                                        if (facturas != null) {
                                            for (Facturacion fac : facturas) {
                                                sb.append(fac.toString() + "\n");

                                            }
                                            JOptionPane.showMessageDialog(null, sb);
                                        } else {
                                            JOptionPane.showMessageDialog(null, "Lo sentimos, actualmente no existe ninguna factura en el sistema");
                                        }
                                        break;

                                    case 2://Creación de una transaccion
                                        sb.setLength(0);
                                        clientes = servicioCliente.conseguirClientes();
                                        productos = servicioProducto.conseguirProductos();
                                        do {
                                            bandera = false;
                                            dia = JOptionPane.showInputDialog("Digite el dia de la transacción");
                                            for (int i = 0; i <= 30; i++) {
                                                if (i == Integer.parseInt(dia)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El dia introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            mes = JOptionPane.showInputDialog("Digite el mes de la transacción");
                                            for (int i = 0; i <= 12; i++) {
                                                if (i == Integer.parseInt(mes)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El mes introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);

                                        do {
                                            bandera = false;
                                            ao = JOptionPane.showInputDialog("Digite el año de la transacción, ejemplo: 2002");
                                            for (int i = 1995; i <= 2023; i++) {
                                                if (i == Integer.parseInt(ao)) {
                                                    bandera = true;
                                                }
                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "El dia introducido no es correcto, por favor intentelo otra vez");
                                            }
                                        } while (bandera != true);
                                        
                                        do {
                                            bandera = false;
                                            sb.setLength(0);
                                            sb.append("Digite la cedula del cliente realiza la transacción \n");
                                            for (Cliente c : clientes) {
                                                sb.append("Cedula: " + c.getCedula_cliente()+ " Nombre completo: " + c.getNombre_cliente() + " " + c.getPrimer_apellido_cliente() + " " + c.getSegundo_apellido_cliente() + "\n");
                                            }

                                            facturacion.setId_cliente(JOptionPane.showInputDialog(null, sb));

                                            for (Cliente c : clientes) {
                                                if (facturacion.getId_cliente().equals(c.getCedula_cliente()) ) {
                                                    bandera = true;
                                                }
                                            }
                                            
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el cliente introducido no es valido");
                                            }
                                        } while (bandera != true);
                                        
                                        do {
                                            bandera = false;
                                            sb.setLength(0);
                                            sb.append("Digite el id del producto que se compra en la transacción \n");
                                            for (Producto p : productos) {
                                                sb.append("ID: " + p.getId_producto()+ " Descripción: " + p.getNombre_producto() + " Precio: $" + p.getPrecio() + "\n");
                                            }

                                            facturacion.setId_producto(Integer.parseInt(JOptionPane.showInputDialog(null, sb)));
                                            facturacion.setNombre_producto(servicioProducto.conseguirProducto(facturacion.getId_producto()).getNombre_producto());
                                            for (Producto p : productos) {
                                                if (facturacion.getId_producto() == p.getId_producto()) {
                                                    bandera = true;
                                                }

                                            }
                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, el producto introducido no es valido");
                                            }
                                        } while (bandera != true);
                                        
                                        do {
                                            bandera = true;
                                            facturacion.setCantidad_ordenada(Integer.parseInt(JOptionPane.showInputDialog("Digite la cantidad del producto que quisiera ordenar")));

                                            for (int ia = 0; ia < letras.length(); ia++) {
                                                for (int ib = 0; ib < Float.toString(facturacion.getCantidad_ordenada()).length(); ib++) {
                                                    if (Float.toString(facturacion.getCantidad_ordenada()).charAt(ib) == letras.charAt(ia)) {
                                                        bandera = false;
                                                    }
                                                }
                                            }

                                            if (bandera == false) {
                                                JOptionPane.showMessageDialog(null, "Lo sentimos, la cantidad del producto la introducida no es valida");
                                            }
                                        } while (bandera != true);
                                        
                                        facturacion.setTotal(facturacion.getCantidad_ordenada() * servicioProducto.conseguirProducto(facturacion.getId_producto()).getPrecio());

                                        try {
                                            fecha = ff.parse(dia + "/" + mes + "/" + ao);
                                            fechaSql = new java.sql.Date(fecha.getTime());
                                            facturacion.setFecha_facturacion(fechaSql);
                                        } catch (ParseException e) {
                                        }

                                        facturacion.setId_factura(servicioFacturacion.buscarUltimoId());
                                        servicioFacturacion.insertarFactura(facturacion);
                                        JOptionPane.showMessageDialog(null, "¡Transacción realizada con exito!");
                                        break;

                                }
                            }
                        } while (opcionB != 0);
                        break;

                }
            }
            if(opcionA == 0){
                JOptionPane.showMessageDialog(null, "¡Que tenga un excelente dia!");
            }
        } while (opcionA != 0);

        //System.out.println(service1.conseguirEmpleado(1));
        /*
        SimpleDateFormat ff = new SimpleDateFormat("DD/MM/YY");
        java.sql.Date fechaSql;
        try{
        Date fecha = ff.parse("13/08/21");
        fechaSql = new java.sql.Date(fecha.getTime());
        
        //Empleado empleado = new Empleado("Donovan","Hidalgo","Montero",fechaSql,"Dono@gmail.com",2,6);
        service.eliminarEmpleado(5);
        }catch(ParseException e){     
        }
         */
    }
}
