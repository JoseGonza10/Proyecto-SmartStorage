
package Objetos;

public class Cliente {
    private String nombre_cliente;
    private String primer_apellido_cliente;
    private String segundo_apellido_cliente;
    private String correo_cliente;
    private String telefono_cliente;
    private String cedula_cliente;

    public Cliente() {
    }

    public Cliente(String nombre_cliente, String primer_apellido_cliente, String segundo_apellido_cliente, String correo_cliente, String telefono_cliente, String cedula_cliente) {
        this.nombre_cliente = nombre_cliente;
        this.primer_apellido_cliente = primer_apellido_cliente;
        this.segundo_apellido_cliente = segundo_apellido_cliente;
        this.correo_cliente = correo_cliente;
        this.telefono_cliente = telefono_cliente;
        this.cedula_cliente = cedula_cliente;
    }

    public String getNombre_cliente() {
        return nombre_cliente;
    }

    public void setNombre_cliente(String nombre_cliente) {
        this.nombre_cliente = nombre_cliente;
    }

    public String getPrimer_apellido_cliente() {
        return primer_apellido_cliente;
    }

    public void setPrimer_apellido_cliente(String primer_apellido_cliente) {
        this.primer_apellido_cliente = primer_apellido_cliente;
    }

    public String getSegundo_apellido_cliente() {
        return segundo_apellido_cliente;
    }

    public void setSegundo_apellido_cliente(String segundo_apellido_cliente) {
        this.segundo_apellido_cliente = segundo_apellido_cliente;
    }

    public String getCorreo_cliente() {
        return correo_cliente;
    }

    public void setCorreo_cliente(String correo_cliente) {
        this.correo_cliente = correo_cliente;
    }

    public String getTelefono_cliente() {
        return telefono_cliente;
    }

    public void setTelefono_cliente(String telefono_cliente) {
        this.telefono_cliente = telefono_cliente;
    }

    public String getCedula_cliente() {
        return cedula_cliente;
    }

    public void setCedula_cliente(String cedula_cliente) {
        this.cedula_cliente = cedula_cliente;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre_cliente=" + nombre_cliente + ", primer_apellido_cliente=" + primer_apellido_cliente + ", segundo_apellido_cliente=" + segundo_apellido_cliente + ", correo_cliente=" + correo_cliente + ", telefono_cliente=" + telefono_cliente + ", cedula_cliente=" + cedula_cliente + '}';
    }
    
    

   
    
    
}
