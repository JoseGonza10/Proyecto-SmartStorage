package Objetos;

import java.sql.Date;

public class Proveedor {
    private String nombre_proveedor;
    private Date fecha_contrato;
    private String correo_proveedor;
    private String telefono_proveedor;
    private int id_proveedor;

    public Proveedor() {
    }

    public Proveedor(String nombre_proveedor, Date fecha_contrato, String correo_proveedor, String telefono_proveedor, int id_proveedor) {
        this.nombre_proveedor = nombre_proveedor;
        this.fecha_contrato = fecha_contrato;
        this.correo_proveedor = correo_proveedor;
        this.telefono_proveedor = telefono_proveedor;
        this.id_proveedor = id_proveedor;
    }

    public String getNombre_proveedor() {
        return nombre_proveedor;
    }

    public void setNombre_proveedor(String nombre_proveedor) {
        this.nombre_proveedor = nombre_proveedor;
    }

    public Date getFecha_contrato() {
        return fecha_contrato;
    }

    public void setFecha_contrato(Date fecha_contrato) {
        this.fecha_contrato = fecha_contrato;
    }

    public String getCorreo_proveedor() {
        return correo_proveedor;
    }

    public void setCorreo_proveedor(String correo_proveedor) {
        this.correo_proveedor = correo_proveedor;
    }

    public String getTelefono_proveedor() {
        return telefono_proveedor;
    }

    public void setTelefono_proveedor(String telefono_proveedor) {
        this.telefono_proveedor = telefono_proveedor;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    @Override
    public String toString() {
        return "nombre_proveedor=" + nombre_proveedor + ", fecha_contrato=" + fecha_contrato + ", correo_proveedor=" + correo_proveedor + ", telefono_proveedor=" + telefono_proveedor + ", id_proveedor=" + id_proveedor;
    }
    
    
}
