package Objetos;

import java.sql.Date;


public class Facturacion {
    private Date fecha_facturacion;
    private float total;
    private int cantidad_ordenada;
    private int id_producto;
    private String id_cliente;
    private String nombre_producto;
    private int id_factura;

    public Facturacion() {
    }

    public Facturacion(Date fecha_facturacion, float total, int cantidad_ordenada, int id_producto, String id_cliente, String nombre_producto, int id_factura) {
        this.fecha_facturacion = fecha_facturacion;
        this.total = total;
        this.cantidad_ordenada = cantidad_ordenada;
        this.id_producto = id_producto;
        this.id_cliente = id_cliente;
        this.nombre_producto = nombre_producto;
        this.id_factura = id_factura;
    }

    public Date getFecha_facturacion() {
        return fecha_facturacion;
    }

    public void setFecha_facturacion(Date fecha_facturacion) {
        this.fecha_facturacion = fecha_facturacion;
    }


    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public int getCantidad_ordenada() {
        return cantidad_ordenada;
    }

    public void setCantidad_ordenada(int cantidad_ordenada) {
        this.cantidad_ordenada = cantidad_ordenada;
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public String getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(String id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNombre_producto() {
        return nombre_producto;
    }

    public void setNombre_producto(String nombre_producto) {
        this.nombre_producto = nombre_producto;
    }

    public int getId_factura() {
        return id_factura;
    }

    public void setId_factura(int id_factura) {
        this.id_factura = id_factura;
    }

    @Override
    public String toString() {
        return "fecha_facturacion=" + fecha_facturacion + ", total=" + total + ", cantidad_ordenada=" + cantidad_ordenada + ", id_producto=" + id_producto + ", id_cliente=" + id_cliente + ", nombre_producto=" + nombre_producto + ", id_factura=" + id_factura;
    }
    
    
  
    
}
