package Objetos;

public class Posicion {

    private String posicion;
    private int id_posicion;

    public Posicion() {
    }

    public Posicion(String posicion, int id_posicion) {
        this.posicion = posicion;
        this.id_posicion = id_posicion;
    }

    public String getPosicion() {
        return posicion;
    }

    public void setPosicion(String posicion) {
        this.posicion = posicion;
    }

    public int getId_posicion() {
        return id_posicion;
    }

    public void setId_posicion(int id_posicion) {
        this.id_posicion = id_posicion;
    }

}
