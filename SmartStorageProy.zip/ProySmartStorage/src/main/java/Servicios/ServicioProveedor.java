package servicios;

import Objetos.Proveedor;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.OracleTypes;
import static servicios.Servicio.conexion;

public class ServicioProveedor extends Servicio {
    
    public Proveedor conseguirProveedor(int idProveedor){
        Proveedor proveedor = new Proveedor();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_proveedores.llamadaObtenerProveedor(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(2, idProveedor);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Proveedor pro = new Proveedor();
               pro.setNombre_proveedor(rs.getString("NOMBRE_PROVEEDOR"));
               pro.setFecha_contrato(rs.getDate("FECHA_CONTRATO"));
               pro.setCorreo_proveedor(rs.getString("CORREO_PROVEEDOR"));
               pro.setTelefono_proveedor(rs.getString("TELEFONO_PROVEEDOR"));
               pro.setId_proveedor(rs.getInt("ID_PROVEEDOR"));
               proveedor = pro;
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return proveedor;
    }
    
     public List<Proveedor> conseguirProveedores(){
        List<Proveedor> proveedores = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_proveedores.llamadaObtenerTodosProveedores(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Proveedor pro = new Proveedor();
               pro.setNombre_proveedor(rs.getString("NOMBRE_PROVEEDOR"));
               pro.setFecha_contrato(rs.getDate("FECHA_CONTRATO"));
               pro.setCorreo_proveedor(rs.getString("CORREO_PROVEEDOR"));
               pro.setTelefono_proveedor(rs.getString("TELEFONO_PROVEEDOR"));
               pro.setId_proveedor(rs.getInt("ID_PROVEEDOR"));
               proveedores.add(pro);
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return proveedores;
    }
     
    public void insertarProveedor(Proveedor proveedor){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_proveedores.InsertarProveedor(?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, proveedor.getNombre_proveedor());
           cStmt.setDate(2, proveedor.getFecha_contrato());
           cStmt.setString(3, proveedor.getCorreo_proveedor());
           cStmt.setString(4, proveedor.getTelefono_proveedor());
           cStmt.setInt(5, proveedor.getId_proveedor());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void actualizarProveedor(Proveedor proveedor){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_proveedores.ActualizarProveedor(?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, proveedor.getId_proveedor());
           cStmt.setString(2, proveedor.getNombre_proveedor());
           cStmt.setDate(3, proveedor.getFecha_contrato());
           cStmt.setString(4, proveedor.getCorreo_proveedor());
           cStmt.setString(5, proveedor.getTelefono_proveedor());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarProveedor(int idProveedor){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_proveedores.EliminarProveedor(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idProveedor);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public int buscarUltimoId() {
        int viejoId = 0;
        List<Proveedor> proveedores = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_proveedores.llamadaObtenerTodosProveedores(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Proveedor pro = new Proveedor();
               pro.setNombre_proveedor(rs.getString("NOMBRE_PROVEEDOR"));
               pro.setFecha_contrato(rs.getDate("FECHA_CONTRATO"));
               pro.setCorreo_proveedor(rs.getString("CORREO_PROVEEDOR"));
               pro.setTelefono_proveedor(rs.getString("TELEFONO_PROVEEDOR"));
               pro.setId_proveedor(rs.getInt("ID_PROVEEDOR"));
               proveedores.add(pro);
           }

            for (Proveedor pro : proveedores) {
                if (viejoId < pro.getId_proveedor()) {
                    viejoId = pro.getId_proveedor();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return viejoId + 1;
    }
    
}
