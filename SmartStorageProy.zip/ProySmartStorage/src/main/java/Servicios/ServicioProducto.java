
package servicios;

import Objetos.Producto;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.OracleTypes;
import static servicios.Servicio.conexion;

public class ServicioProducto extends Servicio{
    
    public Producto conseguirProducto(int idProducto){
        Producto producto = new Producto();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_productos.llamadaObtenerProducto(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(2, idProducto);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Producto pro = new Producto();
               pro.setNombre_producto(rs.getString("NOMBRE_PRODUCTO"));
               pro.setPrecio(rs.getFloat("PRECIO"));
               pro.setCantidad(rs.getInt("CANTIDAD"));
               pro.setId_categoria(rs.getInt("ID_CATEGORIA"));
               pro.setId_proveedor(rs.getInt("ID_PROVEEDOR"));
               pro.setId_producto(rs.getInt("ID_PRODUCTO"));
               producto = pro;
           }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return producto;
    }
    
     public List<Producto> conseguirProductos(){
        List<Producto> productos = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_productos.llamadaObtenerTodosProductos(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Producto pro = new Producto();
               pro.setNombre_producto(rs.getString("NOMBRE_PRODUCTO"));
               pro.setPrecio(rs.getFloat("PRECIO"));
               pro.setCantidad(rs.getInt("CANTIDAD"));
               pro.setId_categoria(rs.getInt("ID_CATEGORIA"));
               pro.setId_proveedor(rs.getInt("ID_PROVEEDOR"));
               pro.setId_producto(rs.getInt("ID_PRODUCTO"));
               productos.add(pro);
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return productos;
    }
     
    public void insertarProducto(Producto producto){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_productos.InsertarProducto(?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, producto.getNombre_producto());
           cStmt.setFloat(2, producto.getPrecio());
           cStmt.setInt(3, producto.getCantidad());
           cStmt.setInt(4, producto.getId_categoria());
           cStmt.setInt(5, producto.getId_proveedor());
           cStmt.setInt(6, producto.getId_producto());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void actualizarProducto(Producto producto){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_productos.ActualizarProducto(?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, producto.getId_producto());
           cStmt.setString(2, producto.getNombre_producto());
           cStmt.setFloat(3, producto.getPrecio());
           cStmt.setInt(4, producto.getCantidad());
           cStmt.setInt(5, producto.getId_categoria());
           cStmt.setInt(6, producto.getId_proveedor());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarProducto(int idProducto){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_productos.EliminarProducto(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idProducto);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
     public void eliminarProductoCategoria(int idCategoria){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_productos.EliminarProductoCategoria(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idCategoria);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
     
    public void eliminarProductoProveedor(int idProveedor){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_productos.EliminarProductoProveedor(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idProveedor);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
  
     public int buscarUltimoId() {
        int viejoId = 0;
        List<Producto> productos = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_productos.llamadaObtenerTodosProductos(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Producto pro = new Producto();
               pro.setNombre_producto(rs.getString("NOMBRE_PRODUCTO"));
               pro.setPrecio(rs.getFloat("PRECIO"));
               pro.setCantidad(rs.getInt("CANTIDAD"));
               pro.setId_categoria(rs.getInt("ID_CATEGORIA"));
               pro.setId_proveedor(rs.getInt("ID_PROVEEDOR"));
               pro.setId_producto(rs.getInt("ID_PRODUCTO"));
               productos.add(pro);
           }

            for (Producto pro : productos) {
                if (viejoId < pro.getId_producto()) {
                    viejoId = pro.getId_producto();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return viejoId + 1;
    }
    
}
