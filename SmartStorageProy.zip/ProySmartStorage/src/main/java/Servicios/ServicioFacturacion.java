package servicios;

import Objetos.Facturacion;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.OracleTypes;
import static servicios.Servicio.conexion;


public class ServicioFacturacion extends Servicio {
    
    public Facturacion conseguirFactura(int IdFactura){
        Facturacion factura = new Facturacion();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_facturacion.llamadaObtenerFactura(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(2, IdFactura);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Facturacion fac = new Facturacion();
               fac.setFecha_facturacion(rs.getDate("FECHA_FACTURACION"));
               fac.setTotal(rs.getFloat("TOTAL"));
               fac.setCantidad_ordenada(rs.getInt("CANTIDAD_ORDENADA"));
               fac.setId_producto(rs.getInt("ID_PRODUCTO"));
               fac.setId_cliente(rs.getString("ID_CLIENTE"));
               fac.setNombre_producto(rs.getString("NOMBRE_PRODUCTO"));
               fac.setId_factura(rs.getInt("ID_FACTURA"));
               factura = fac;
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return factura;
    }
    
     public List<Facturacion> conseguirFacturas(){
        List<Facturacion> facturas = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_facturacion.llamadaObtenerTodasFacturas(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Facturacion fac = new Facturacion();
               fac.setFecha_facturacion(rs.getDate("FECHA_FACTURACION"));
               fac.setTotal(rs.getFloat("TOTAL"));
               fac.setCantidad_ordenada(rs.getInt("CANTIDAD_ORDENADA"));
               fac.setId_producto(rs.getInt("ID_PRODUCTO"));
               fac.setId_cliente(rs.getString("ID_CLIENTE"));
               fac.setNombre_producto(rs.getString("NOMBRE_PRODUCTO"));
               fac.setId_factura(rs.getInt("ID_FACTURA"));
               facturas.add(fac);
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return facturas;
    }
     
    public void insertarFactura(Facturacion factura){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_facturacion.InsertarFactura(?,?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setDate(1, factura.getFecha_facturacion());
           cStmt.setFloat(2, factura.getTotal());
           cStmt.setInt(3, factura.getCantidad_ordenada());
           cStmt.setInt(4, factura.getId_producto());
           cStmt.setString(5, factura.getId_cliente());
           cStmt.setString(6, factura.getNombre_producto());
           cStmt.setInt(7, factura.getId_factura());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void actualizarFactura(Facturacion factura){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_facturacion.ActualizarFactura(?,?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, factura.getId_factura());
           cStmt.setDate(2, factura.getFecha_facturacion());
           cStmt.setFloat(3, factura.getTotal());
           cStmt.setInt(4, factura.getCantidad_ordenada());
           cStmt.setInt(5, factura.getId_producto());
           cStmt.setString(6, factura.getId_cliente());
           cStmt.setString(7,factura.getNombre_producto());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarFactura(int idFactura){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_facturacion.EliminarFactura(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idFactura);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarFacturaProducto(int idProducto){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_facturacion.EliminarFacturaProducto(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idProducto);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarFacturaCliente(String idCliente){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_facturacion.EliminarFacturaCliente(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, idCliente);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public int buscarUltimoId() {
        int viejoId = 0;
        List<Facturacion> facturas = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call pkg_facturacion.llamadaObtenerTodasFacturas(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Facturacion fac = new Facturacion();
               fac.setFecha_facturacion(rs.getDate("FECHA_FACTURACION"));
               fac.setTotal(rs.getFloat("TOTAL"));
               fac.setCantidad_ordenada(rs.getInt("CANTIDAD_ORDENADA"));
               fac.setId_producto(rs.getInt("ID_PRODUCTO"));
               fac.setId_cliente(rs.getString("ID_CLIENTE"));
               fac.setNombre_producto(rs.getString("NOMBRE_PRODUCTO"));
               fac.setId_factura(rs.getInt("ID_FACTURA"));
               facturas.add(fac);
           }

            for (Facturacion fac : facturas) {
                if (viejoId < fac.getId_factura()) {
                    viejoId = fac.getId_factura();
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return viejoId + 1;
    }
    
}
