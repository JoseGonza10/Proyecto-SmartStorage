package servicios;

import Objetos.Posicion;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.OracleTypes;
import static servicios.Servicio.conexion;

public class ServicioPosicion extends Servicio {

    public Posicion conseguirPosicion(int idPosicion) {
        Posicion posicion = new Posicion();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try {
            super.abrirConexion();
            String consulta = "{call pkg_posicion.llamadaObtenerPosicion(?,?)}";
            cStmt = conexion.prepareCall(consulta);
            cStmt.setInt(2, idPosicion);
            cStmt.registerOutParameter(1, OracleTypes.CURSOR);
            cStmt.execute();
            rs = (ResultSet) cStmt.getObject(1);

            while (rs.next()) {
                Posicion pos = new Posicion();
                pos.setPosicion(rs.getString("POSICION"));
                pos.setId_posicion(rs.getInt("ID_POSICION"));
                posicion = pos;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return posicion;
    }

    public List<Posicion> conseguirPosiciones() {
        List<Posicion> posiciones = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try {
            super.abrirConexion();
            String consulta = "{call pkg_posicion.llamadaObtenerTodasPosiciones(?)}";
            cStmt = conexion.prepareCall(consulta);
            cStmt.registerOutParameter(1, OracleTypes.CURSOR);
            cStmt.execute();
            rs = (ResultSet) cStmt.getObject(1);
            while (rs.next()) {
                Posicion pos = new Posicion();
                pos.setPosicion(rs.getString("POSICION"));
                pos.setId_posicion(rs.getInt("ID_POSICION"));
                posiciones.add(pos);
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return posiciones;
    }

    public void InsertarPosicion(Posicion posicion) {
        CallableStatement cStmt = null;
        try {
            super.abrirConexion();
            String consulta = "{call pkg_posicion.InsertarPosicion(?,?)}";
            cStmt = conexion.prepareCall(consulta);
            cStmt.setString(1, posicion.getPosicion());
            cStmt.setInt(2, posicion.getId_posicion());
            cStmt.execute();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }

    public void actualizarPosicion(Posicion posicion) {
        CallableStatement cStmt = null;
        try {
            super.abrirConexion();
            String consulta = "{call pkg_posicion.ActualizarPosicion(?,?)}";
            cStmt = conexion.prepareCall(consulta);
            cStmt.setInt(2, posicion.getId_posicion());
            cStmt.setString(1, posicion.getPosicion());
            cStmt.execute();

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }

    public void eliminarPosicion(int idPosicion) {
        CallableStatement cStmt = null;
        try {
            super.abrirConexion();
            String consulta = "{call pkg_posicion.EliminarPosicion(?)}";
            cStmt = conexion.prepareCall(consulta);
            cStmt.setInt(1, idPosicion);
            cStmt.execute();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }

}
