package servicios;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import objetos.Empleado;
import oracle.jdbc.OracleTypes;


public class Servicio {
    protected static Connection conexion = null;
    private String url = "jdbc:oracle:thin:@localhost:1521:ORCL";
    private String usuario = "hr";
    private String clave = "54345";
    
    public Connection abrirConexion(){
        try{
        Class.forName("oracle.jdbc.OracleDriver");
        conexion = DriverManager.getConnection(url,usuario,clave);
        }catch(ClassNotFoundException ce){
        ce.printStackTrace();
        }catch(SQLException se){
        se.printStackTrace();
        }
        return conexion;
    }
    
    public void cerrarConexion(){
        try{
        if(conexion != null && conexion.isClosed()){
            conexion.close();
            conexion = null;
        }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public void cerrarStatement(PreparedStatement stmt){
        try{
        if(stmt != null && stmt.isClosed()){
            stmt.close();
            stmt = null;
        }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    
        public void cerrarResultSet(ResultSet rs){
        try{
        if(rs != null && rs.isClosed()){
            rs.close();
            rs = null;
        }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    
    public void probarConexion(){
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try{
           abrirConexion();
           String consulta = "{CALL ObtenerTodosProvedores}";
           stmt = conexion.prepareStatement(consulta);
           rs = stmt.executeQuery();
           System.out.println("Estoy aca 2");
           while(rs.next()){
               System.out.println("Estoy aca");
               System.out.println(rs.getString(1));
           }
           
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(stmt);
            cerrarResultSet(rs);
        }
    }
    
    public void probarStoredProcedure(){
        List<Empleado> empleados = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           abrirConexion();
           String consulta = "{call llamadaObtenerTodosEmpleados(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Empleado emp = new Empleado();
               emp.setNombre_empleado(rs.getString("NOMBRE_EMPLEADO"));
               emp.setPrimer_apellido_empleado(rs.getString("PRIMER_APELLIDO_EMPLEADO"));
               empleados.add(emp);
               System.out.println(emp.getNombre_empleado() + emp.getPrimer_apellido_empleado() );
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
    }


   
    
}
