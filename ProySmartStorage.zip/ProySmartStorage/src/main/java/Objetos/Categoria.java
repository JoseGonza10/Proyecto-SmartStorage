
package Objetos;

public class Categoria {
    private String categoria;
    private int id_categoria;

    public Categoria() {
    }

    public Categoria(String categoria, int id_categoria) {
        this.categoria = categoria;
        this.id_categoria = id_categoria;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getId_categoria() {
        return id_categoria;
    }

    public void setId_categoria(int id_categoria) {
        this.id_categoria = id_categoria;
    }
    
    
}
