package objetos;

import java.sql.Date;

public class Empleado {
    private String nombre_empleado;
    private String primer_apellido_empleado;
    private String segundo_apellido_empleado;
    private Date fecha_contratacion;
    private String correo_empleado;
    private int id_empleado;
    private int id_posicion;

    public Empleado() {
    }

    public Empleado(String nombre_empleado, String primer_apellido_empleado, String segundo_apellido_empleado, Date fecha_contratacion, String correo_empleado, int id_empleado, int id_posicion) {
        this.nombre_empleado = nombre_empleado;
        this.primer_apellido_empleado = primer_apellido_empleado;
        this.segundo_apellido_empleado = segundo_apellido_empleado;
        this.fecha_contratacion = fecha_contratacion;
        this.correo_empleado = correo_empleado;
        this.id_empleado = id_empleado;
        this.id_posicion = id_posicion;
    }

    public String getNombre_empleado() {
        return nombre_empleado;
    }

    public void setNombre_empleado(String nombre_empleado) {
        this.nombre_empleado = nombre_empleado;
    }

    public String getPrimer_apellido_empleado() {
        return primer_apellido_empleado;
    }

    public void setPrimer_apellido_empleado(String primer_apellido_empleado) {
        this.primer_apellido_empleado = primer_apellido_empleado;
    }

    public String getSegundo_apellido_empleado() {
        return segundo_apellido_empleado;
    }

    public void setSegundo_apellido_empleado(String segundo_apellido_empleado) {
        this.segundo_apellido_empleado = segundo_apellido_empleado;
    }

    public Date getFecha_contratacion() {
        return fecha_contratacion;
    }

    public void setFecha_contratacion(Date fecha_contratacion) {
        this.fecha_contratacion = fecha_contratacion;
    }

    public String getCorreo_empleado() {
        return correo_empleado;
    }

    public void setCorreo_empleado(String correo_empleado) {
        this.correo_empleado = correo_empleado;
    }

    public int getId_empleado() {
        return id_empleado;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public int getId_posicion() {
        return id_posicion;
    }

    public void setId_posicion(int id_posicion) {
        this.id_posicion = id_posicion;
    }

    @Override
    public String toString() {
        return "Empleado{" + "nombre_empleado=" + nombre_empleado + ", primer_apellido_empleado=" + primer_apellido_empleado + ", segundo_apellido_empleado=" + segundo_apellido_empleado + ", fecha_contratacion=" + fecha_contratacion + ", correo_empleado=" + correo_empleado + ", id_empleado=" + id_empleado + ", id_posicion=" + id_posicion + '}';
    }
    
    
    
    
    

    
    
    
    
    
    
}
