
package servicios;

import Objetos.Cliente;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.OracleTypes;
import static servicios.Servicio.conexion;

public class ServicioCliente extends Servicio{
    
    public Cliente conseguirCliente(String idCliente){
        Cliente cliente = new Cliente();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call llamadaObtenerCliente(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(2, idCliente);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Cliente cli = new Cliente();
               cli.setNombre_cliente(rs.getString("NOMBRE_CLIENTE"));
               cli.setPrimer_apellido_cliente(rs.getString("PRIMER_APELLIDO_CLIENTE"));
               cli.setSegundo_apellido_cliente(rs.getString("SEGUNDO_APELLIDO_CLIENTE"));
               cli.setCorreo_cliente(rs.getString("CORREO_CLIENTE"));
               cli.setTelefono_cliente(rs.getString("TELEFONO_CLIENTE"));
               cli.setCedula_cliente(rs.getString("CEDULA_CLIENTE"));
               cliente = cli;
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return cliente;
    }
    
     public List<Cliente> conseguirClientes(){
        List<Cliente> clientes = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call llamadaObtenerTodosClientes(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Cliente cli = new Cliente();
               cli.setNombre_cliente(rs.getString("NOMBRE_CLIENTE"));
               cli.setPrimer_apellido_cliente(rs.getString("PRIMER_APELLIDO_CLIENTE"));
               cli.setSegundo_apellido_cliente(rs.getString("SEGUNDO_APELLIDO_CLIENTE"));
               cli.setCorreo_cliente(rs.getString("CORREO_CLIENTE"));
               cli.setTelefono_cliente(rs.getString("TELEFONO_CLIENTE"));
               cli.setCedula_cliente(rs.getString("CEDULA_CLIENTE"));
               clientes.add(cli);
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return clientes;
    }
     
    public void insertarCliente(Cliente cliente){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call insertarCliente(?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, cliente.getNombre_cliente());
           cStmt.setString(2, cliente.getPrimer_apellido_cliente());
           cStmt.setString(3, cliente.getSegundo_apellido_cliente());
           cStmt.setString(4, cliente.getCorreo_cliente());
           cStmt.setString(5, cliente.getTelefono_cliente());
           cStmt.setString(6, cliente.getCedula_cliente());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void actualizarCliente(Cliente cliente){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call ActualizarCliente(?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, cliente.getCedula_cliente());
           cStmt.setString(2, cliente.getNombre_cliente());
           cStmt.setString(3, cliente.getPrimer_apellido_cliente());
           cStmt.setString(4, cliente.getSegundo_apellido_cliente());
           cStmt.setString(5, cliente.getCorreo_cliente());
           cStmt.setString(6, cliente.getTelefono_cliente());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarCliente(String idCliente){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call EliminarCliente(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, idCliente);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
}
