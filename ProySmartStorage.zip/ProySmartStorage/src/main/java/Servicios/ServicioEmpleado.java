
package servicios;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import objetos.Empleado;
import oracle.jdbc.OracleTypes;


public class ServicioEmpleado extends Servicio{
    
    
    
    public Empleado conseguirEmpleado(int IdEmpleado){
        Empleado empleado = new Empleado();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call llamadaObtenerEmpleado(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(2, IdEmpleado);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Empleado emp = new Empleado();
               emp.setNombre_empleado(rs.getString("NOMBRE_EMPLEADO"));
               emp.setPrimer_apellido_empleado(rs.getString("PRIMER_APELLIDO_EMPLEADO"));
               emp.setSegundo_apellido_empleado(rs.getString("SEGUNDO_APELLIDO_EMPLEADO"));
               emp.setFecha_contratacion(rs.getDate("FECHA_CONTRATACION"));
               emp.setCorreo_empleado(rs.getString("CORREO_EMPLEADO"));
               emp.setId_empleado(rs.getInt("ID_EMPLEADO"));
               emp.setId_posicion(rs.getInt("ID_POSICION"));
               empleado = emp;
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return empleado;
    }
    
     public List<Empleado> conseguirEmpleados(){
        List<Empleado> empleados = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call llamadaObtenerTodosEmpleados(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Empleado emp = new Empleado();
               emp.setNombre_empleado(rs.getString("NOMBRE_EMPLEADO"));
               emp.setPrimer_apellido_empleado(rs.getString("PRIMER_APELLIDO_EMPLEADO"));
               emp.setSegundo_apellido_empleado(rs.getString("SEGUNDO_APELLIDO_EMPLEADO"));
               emp.setFecha_contratacion(rs.getDate("FECHA_CONTRATACION"));
               emp.setCorreo_empleado(rs.getString("CORREO_EMPLEADO"));
               emp.setId_empleado(rs.getInt("ID_EMPLEADO"));
               emp.setId_posicion(rs.getInt("ID_POSICION"));
               empleados.add(emp);
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return empleados;
    }
     
    public void insertarEmpleado(Empleado empleado){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call InsertarEmpleado(?,?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, empleado.getNombre_empleado());
           cStmt.setString(2, empleado.getPrimer_apellido_empleado());
           cStmt.setString(3, empleado.getSegundo_apellido_empleado());
           cStmt.setDate(4, empleado.getFecha_contratacion());
           cStmt.setString(5, empleado.getCorreo_empleado());
           cStmt.setInt(6, empleado.getId_empleado());
           cStmt.setInt(7, empleado.getId_posicion());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void actualizarEmpleado(Empleado empleado){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call ActualizarEmpleado(?,?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, empleado.getId_empleado());
           cStmt.setString(2, empleado.getNombre_empleado());
           cStmt.setString(3, empleado.getPrimer_apellido_empleado());
           cStmt.setString(4, empleado.getSegundo_apellido_empleado());
           cStmt.setDate(5, empleado.getFecha_contratacion());
           cStmt.setString(6, empleado.getCorreo_empleado());
           cStmt.setInt(7, empleado.getId_posicion());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarEmpleado(int idEmpleado){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call eliminarEmpleado(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idEmpleado);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
}
