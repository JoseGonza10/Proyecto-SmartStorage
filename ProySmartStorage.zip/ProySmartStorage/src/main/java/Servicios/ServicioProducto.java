
package servicios;

import Objetos.Producto;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.OracleTypes;
import static servicios.Servicio.conexion;

public class ServicioProducto extends Servicio{
    
    public Producto conseguirProducto(int idProducto){
        Producto producto = new Producto();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call llamadaObtenerProducto(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(2, idProducto);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Producto pro = new Producto();
               pro.setNombre_producto(rs.getString("NOMBRE_PRODUCTO"));
               pro.setPrecio(rs.getFloat("PRECIO"));
               pro.setCantidad(rs.getInt("CANTIDAD"));
               pro.setId_categoria(rs.getInt("ID_CATEGORIA"));
               pro.setId_proveedor(rs.getInt("ID_PROVEEDOR"));
               pro.setId_producto(rs.getInt("ID_PRODUCTO"));
               producto = pro;
           }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return producto;
    }
    
     public List<Producto> conseguirProductos(){
        List<Producto> productos = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call llamadaObtenerTodosProductos(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Producto pro = new Producto();
               pro.setNombre_producto(rs.getString("NOMBRE_PRODUCTO"));
               pro.setPrecio(rs.getFloat("PRECIO"));
               pro.setCantidad(rs.getInt("CANTIDAD"));
               pro.setId_categoria(rs.getInt("ID_CATEGORIA"));
               pro.setId_proveedor(rs.getInt("ID_PROVEEDOR"));
               pro.setId_producto(rs.getInt("ID_PRODUCTO"));
               productos.add(pro);
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return productos;
    }
     
    public void insertarProducto(Producto producto){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call InsertarProducto(?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, producto.getNombre_producto());
           cStmt.setFloat(2, producto.getPrecio());
           cStmt.setInt(3, producto.getCantidad());
           cStmt.setInt(4, producto.getId_categoria());
           cStmt.setInt(5, producto.getId_proveedor());
           cStmt.setInt(6, producto.getId_producto());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void actualizarProducto(Producto producto){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call ActualizarProducto(?,?,?,?,?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, producto.getId_producto());
           cStmt.setString(2, producto.getNombre_producto());
           cStmt.setFloat(3, producto.getPrecio());
           cStmt.setInt(4, producto.getCantidad());
           cStmt.setInt(5, producto.getId_categoria());
           cStmt.setInt(6, producto.getId_proveedor());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarProducto(int idProducto){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call EliminarProducto(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idProducto);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
}
