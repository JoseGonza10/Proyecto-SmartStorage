
package servicios;

import Objetos.Categoria;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import oracle.jdbc.OracleTypes;
import static servicios.Servicio.conexion;


public class ServicioCategoria extends Servicio{
    
     public Categoria conseguirCategoria(int idCategoria){
        Categoria categoria = new Categoria();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call llamadaObtenerCategoria(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(2, idCategoria);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           while(rs.next()){
               Categoria cat = new Categoria();
               cat.setCategoria(rs.getString("CATEGORIA"));
               cat.setId_categoria(rs.getInt("ID_CATEGORIA"));
               categoria = cat;
           }
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return categoria;
    }
    
     public List<Categoria> conseguirCategorias(){
        List<Categoria> categorias = new ArrayList<>();
        CallableStatement cStmt = null;
        ResultSet rs = null;
        try{
           super.abrirConexion();
           String consulta = "{call llamadaObtenerTodasCategorias(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.registerOutParameter(1,OracleTypes.CURSOR);
           cStmt.execute();
           rs = (ResultSet) cStmt.getObject(1);
           
           while(rs.next()){
               Categoria cat = new Categoria();
               cat.setCategoria(rs.getString("CATEGORIA"));
               cat.setId_categoria(rs.getInt("ID_CATEGORIA"));
               categorias.add(cat);
           }
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
            cerrarResultSet(rs);
        }
        return categorias;
    }
     
    public void insertarCategoria(Categoria categoria){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call InsertarCategoria(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setString(1, categoria.getCategoria());
           cStmt.setInt(2, categoria.getId_categoria());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void actualizarCategoria(Categoria categoria){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call ActualizarCategoria(?,?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, categoria.getId_categoria());
           cStmt.setString(2, categoria.getCategoria());
           cStmt.execute();
          
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
    public void eliminarCategoria(int idCategoria){
        CallableStatement cStmt = null;
        try{
           super.abrirConexion();
           String consulta = "{call EliminarCategoria(?)}";
           cStmt = conexion.prepareCall(consulta);
           cStmt.setInt(1, idCategoria);
           cStmt.execute();
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            cerrarConexion();
            cerrarStatement(cStmt);
        }
    }
    
}
