package com.mycompany.proysmartstorage;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import objetos.Empleado;
import servicios.Servicio;
import servicios.ServicioEmpleado;

public class ProySmartStorage {

    public static void main(String[] args) {
        SimpleDateFormat ff = new SimpleDateFormat("DD/MM/YY");
        java.sql.Date fechaSql;
        try{
        Date fecha = ff.parse("13/08/21");
        fechaSql = new java.sql.Date(fecha.getTime());
        ServicioEmpleado service = new ServicioEmpleado();
        //System.out.println(service.conseguirEmpleados());
        //System.out.println(service.conseguirEmpleado(1));
        //Empleado empleado = new Empleado("Donovan","Hidalgo","Montero",fechaSql,"Dono@gmail.com",2,6);
        service.eliminarEmpleado(5);
        }catch(ParseException e){     
        }
        
    }
}
